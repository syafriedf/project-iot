<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Halo Indonesia</h1>
</body>
</html><?php /**PATH F:\XAMPP\htdocs\first_app\resources\views/operator/index.blade.php ENDPATH**/ ?>